#include <iostream>
using namespace std;

int main(){
    int a = 1;
    int b = 0;
    int* p1 = &a;
    int* p2 = &b;
    cout<<*p1<<", "<<*p2<<endl;
    swap<int*>(p1,p2);
    cout<<*p1<<", "<<*p2<<endl;

    return 0;
}